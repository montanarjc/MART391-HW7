package com.example.hw7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Timer timer = new Timer();
    ImageView myView;
    int starSpeedX = 10;
    int starSpeedY = -17;
    int sunSpeedX = 30;
    int sunSpeedY = 9;
    int galaxySpeedX = -3;
    int galaxySpeedY = 3;

    // If I was better at this, I would create an array of objects that contained
    // the image and their velocities.  Then just one procedure to move all of them.  :)
    // Here is the quick and dirty version:

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //myView = (ImageView)findViewById(R.id.star);
        //myView.setX(myView.getX()+300);

        timer.schedule(new MoveTask(),1,80);
    }
    class MoveTask extends TimerTask {
        public void run() {
            moveStar();
            moveSun();
            moveGalaxy();
        }
    }
    public void moveStar() {
        myView = (ImageView) findViewById(R.id.star);
        myView.setY(myView.getY() + starSpeedY);
        myView.setX(myView.getX() + starSpeedX);

        if (myView.getX() + myView.getWidth() >= getScreenWidth() || myView.getX() <= 0) {
            starSpeedX *= -1;
            if (starSpeedX < 0) {
                starSpeedX -= 1;
            } else {
                starSpeedX += 1;
            }
        }
        if (myView.getY() + myView.getHeight() >= (getScreenHeight()-100) || myView.getY() <= 0)
            starSpeedY *= -1;
        if (starSpeedY < 0) {
            starSpeedY -= 1;
        } else {
            starSpeedY += 1;
        }
        if ((Math.abs(starSpeedX) > 210)) {
            starSpeedX = 42;
        }
        if ((Math.abs(starSpeedY) > 270)) {
            starSpeedY = 11;
        }
    }
    public void moveSun() {
        myView = (ImageView)findViewById(R.id.sun);
        myView.setY(myView.getY()+sunSpeedY);
        myView.setX(myView.getX()+sunSpeedX);

        if(myView.getX() + myView.getWidth() >= getScreenWidth() || myView.getX() <= 0)
        {
            sunSpeedX *= -1;
            if (sunSpeedX < 0) {
                sunSpeedX -= 1;
            } else {
                sunSpeedX += 1;
            }
        }
        if(myView.getY() + myView.getHeight() >= getScreenHeight() || myView.getY() <= 0)
            sunSpeedY *= -1;
        if (sunSpeedY < 0) {
            sunSpeedY -= 1;
        } else {
            sunSpeedY += 1;
        }
        if ((Math.abs(sunSpeedX) > 110)){
            sunSpeedX = 43;
        }
        if ((Math.abs(sunSpeedY) > 170)){
            sunSpeedY = 20;
        }
    }

    public void moveGalaxy() {
        myView = (ImageView)findViewById(R.id.galaxy);
        myView.setY(myView.getY()+galaxySpeedY);
        myView.setX(myView.getX()+galaxySpeedX);

        if(myView.getX() + myView.getWidth() >= getScreenWidth() || myView.getX() <= 0)
        {
            galaxySpeedX *= -1;
            if (galaxySpeedX < 0) {
                galaxySpeedX -= 1;
            } else {
                galaxySpeedX += 1;
            }
        }
        if(myView.getY() + myView.getHeight() >= getScreenHeight() || myView.getY() <= 0)
            galaxySpeedY *= -1;
        if (galaxySpeedY < 0) {
            galaxySpeedY -= 1;
        } else {
            galaxySpeedY += 1;
        }
        if ((Math.abs(galaxySpeedX) > 150)){
            galaxySpeedX=11;
        }
        if ((Math.abs(galaxySpeedY) > 170)){
            galaxySpeedY=11;
        }

    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }
    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }
}
